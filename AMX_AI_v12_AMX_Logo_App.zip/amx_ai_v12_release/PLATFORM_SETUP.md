# Platform setup

## Android
Add microphone permission to `android/app/src/main/AndroidManifest.xml`:

```xml
<uses-permission android:name="android.permission.RECORD_AUDIO" />
<uses-permission android:name="android.permission.INTERNET" />
```

For production, use HTTPS for `API_BASE_URL`.

## iOS
Add to `ios/Runner/Info.plist`:

```xml
<key>NSMicrophoneUsageDescription</key>
<string>AMX AI uses your microphone for voice conversations.</string>
```

## Web
The browser must be served from HTTPS for microphone/WebRTC in production (localhost is permitted during local development).

## Realtime voice
v12 uses a server-issued short-lived client secret. The permanent OpenAI API key stays on the server. The Flutter realtime client then establishes a WebRTC session with the OpenAI realtime endpoint.

Because realtime APIs can change, verify the current OpenAI Realtime WebRTC/client-secret flow immediately before production deployment.
