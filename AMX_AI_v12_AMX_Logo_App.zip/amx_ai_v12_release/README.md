# AMX AI v12 — Realtime + Release Configuration

AMX AI is an independent AI application built with Flutter and a Node.js backend. It is not a copy of ChatGPT source code.

## v12 additions
- Realtime voice session-token endpoint for GPT-Realtime-2.1.
- Configurable API base URL in Flutter via `--dart-define=API_BASE_URL=...`.
- Buffered SSE parsing for streamed chat responses.
- Conversation drawer: create/select chats and load history.
- Settings/profile screen with account, plan/usage, model and API configuration.
- Generated-image result rendering when the API returns a data URL.
- Production-oriented Dockerfile and `.dockerignore`.
- Configurable CORS origin.
- Safer upload MIME/size allowlist.
- Health endpoint reports v12.

## Important realtime note
The server endpoint `/realtime/client-secret` creates a short-lived realtime client secret using your server-side OpenAI API key. The Flutter client must use that short-lived secret for the browser/mobile WebRTC session; never put `OPENAI_API_KEY` in Flutter.

The exact realtime client flow can evolve with the OpenAI Realtime API. Check the current OpenAI Realtime documentation before production release.

## Run locally

### Server
1. Create PostgreSQL database.
2. Run `database/schema.sql`.
3. Copy `server/.env.example` to `server/.env`.
4. Set `OPENAI_API_KEY`, `JWT_SECRET`, and `DATABASE_URL`.
5. `cd server && npm install && npm start`

### Flutter
`cd app && flutter pub get`

Android/iOS/Web development:

```bash
flutter run --dart-define=API_BASE_URL=http://YOUR_SERVER:3000
```

Web production example:

```bash
flutter build web --dart-define=API_BASE_URL=https://api.example.com
```

## Production checklist
- HTTPS everywhere.
- Managed PostgreSQL with migrations/backups.
- Private object storage instead of local uploads.
- Malware scanning and strict MIME/content validation.
- Distributed rate limiting (Redis or managed equivalent).
- Refresh-token/session revocation instead of relying only on long-lived JWTs.
- Verify Apple/Google subscriptions server-side before granting Premium.
- Add automated tests and CI/CD.
- Configure `ALLOWED_ORIGINS` instead of `*`.
- Add observability, audit logs, and privacy/retention controls.
- Review the current OpenAI API documentation before shipping realtime voice.
