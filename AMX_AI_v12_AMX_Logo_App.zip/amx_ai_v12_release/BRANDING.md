# AMX AI Branding

The AMX AI app uses the custom cursive capital **A** logo generated for this release.

- Master app asset: `app/assets/amx_logo.png`
- Web icons: `web/icons/Icon-192.png` and `web/icons/Icon-512.png`
- Flutter launcher icon configuration is included in `app/pubspec.yaml`.

From the `app` directory, run:

```bash
flutter pub get
flutter pub run flutter_launcher_icons
flutter run
```

The launcher command generates Android/iOS/Web launcher assets from the supplied logo.
